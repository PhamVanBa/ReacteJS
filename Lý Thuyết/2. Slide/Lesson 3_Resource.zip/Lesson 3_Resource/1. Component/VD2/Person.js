import React from 'react';
import './Person.css';

function Person() {
    return (
        <div className="person">
            <h1>FullName: Nguyễn Văn A</h1>
            <p>Age: 25</p>
        </div>
    );
}

export default Person;