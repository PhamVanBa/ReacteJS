import './App.css';
import React from 'react';
import Person from './Person';

function App() {
  return (
    <div>
      <Person />
      <Person />
      <Person />
    </div>
  );
}

export default App;
