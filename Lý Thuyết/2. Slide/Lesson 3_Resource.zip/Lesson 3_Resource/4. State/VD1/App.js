import './App.css';
import React from 'react';
import Clock from './Clock';

function App() {
  return (
    <div>
      <Clock />
    </div>
  );
}

export default App;
