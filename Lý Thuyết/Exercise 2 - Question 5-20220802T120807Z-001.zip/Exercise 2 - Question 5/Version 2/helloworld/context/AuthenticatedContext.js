import React from 'react';

const AuthenticatedContext = React.createContext();

export default AuthenticatedContext;


