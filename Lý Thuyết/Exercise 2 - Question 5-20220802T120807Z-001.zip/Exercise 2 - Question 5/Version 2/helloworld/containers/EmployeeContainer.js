import React from 'react';
import EmployeeApi from '../api/EmployeeApi';
import EmployeeList from '../components/EmployeeList';
import WithLoading from '../hoc/withLoading';
import withAuth from '../hoc/withAuth';
import withContextConsumer from '../hoc/withContextConsumer';
import { ThemeContext } from '../context/ThemeContext';
import AuthenticatedContext from '../context/AuthenticatedContext';

class EmployeeContainer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            employees: []
        };
    }

    getListEmployee = async () => {
        try {
            // call api
            const employees = await EmployeeApi.getAll();
            // using data
            this.setState({
                employees: employees
            });
        } catch (error) {
            console.log(error);
        }
    }

    componentDidMount() {
        this.getListEmployee();
    }

    render() {
        console.log(this.props);
        const EmployeeListWithLoading = WithLoading(EmployeeList);

        return (
            <EmployeeListWithLoading
                isLoading={this.state.employees.length === 0}
                employees={this.state.employees} />
        );
    }
}

const withThemeContextConsumer = withContextConsumer(ThemeContext, EmployeeContainer);
const withAuthenticatedContextConsumer = withContextConsumer(AuthenticatedContext, withThemeContextConsumer);
export default withAuth(withAuthenticatedContextConsumer);

// export default withContextConsumer(
//     AuthenticatedContext,
//     withContextConsumer(
//         ThemeContext,
//         withAuth(EmployeeContainer)
//     )
// );




