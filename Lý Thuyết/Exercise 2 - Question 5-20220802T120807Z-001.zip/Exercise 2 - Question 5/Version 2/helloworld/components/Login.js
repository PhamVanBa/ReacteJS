import React from 'react';

function Login(props) {

    return (
        <div>
            Please <a href="/login">login</a> to view
        </div>
    );

}

export default Login;




