import './App.css'

import React from "react";
import { Switch, Route, Link, Redirect } from "react-router-dom";
import Home from "./components/Home";
import EmployeeContainer from './containers/EmployeeContainer';
import UserContainer from './containers/UserContainer';
import { ThemeContext, themes } from './context/ThemeContext';
import withContextProvider from './hoc/withContextProvider';
import AuthenticatedContext from './context/AuthenticatedContext';

class AppContainer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isAuthenticated: true
    }
  }

  render() {
    const AppWithAuthenticatedContext = withContextProvider(AuthenticatedContext, App, { isAuthenticated: this.state.isAuthenticated });
    const AppWithAuthenticatedThemeContext = withContextProvider(ThemeContext, AppWithAuthenticatedContext, themes.dark);

    return (
      <AppWithAuthenticatedThemeContext />
    );
  }
}

class App extends React.Component {
  render() {
    return (
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/employees">Employee List (Protected)</Link>
            </li>
            <li>
              <Link to="/users">User List</Link>
            </li>
          </ul>
        </nav>

        <Switch>
          <Route path="/" component={Home} exact />
          <Route path="/employees" component={EmployeeContainer} exact />
          <Route path="/users" component={UserContainer} exact />
          <Redirect to="/" />
        </Switch>
      </div>
    );
  }
}

export default AppContainer;



