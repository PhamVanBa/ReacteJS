import React from 'react';

function withContextProvider(ContextComponent, WrappedComponent, context) {

    class HOC extends React.Component {

        render() {
            return (
                <ContextComponent.Provider value={context}>
                    <WrappedComponent {...this.props} />
                </ContextComponent.Provider>
            );
        }
    }

    HOC.displayName = `withContextProvider(${getDisplayName(WrappedComponent)})`;

    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

export default withContextProvider;

