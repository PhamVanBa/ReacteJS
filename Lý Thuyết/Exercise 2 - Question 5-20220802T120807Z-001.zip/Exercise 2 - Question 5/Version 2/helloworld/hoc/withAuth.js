import React from 'react';
import Login from '../components/Login';
import AuthenticatedContext from '../context/AuthenticatedContext';

function withAuth(AuthenticatedComponent) {

    class HOC extends React.Component {

        isAuthenticated = () => {
            console.log(this.context);
            return this.context.isAuthenticated;
        }

        render() {
            return !this.isAuthenticated() ? <Login /> : <AuthenticatedComponent {...this.props} />;
        }
    }

    HOC.contextType = AuthenticatedContext;
    HOC.displayName = `withAuth(${getDisplayName(AuthenticatedComponent)})`
    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

export default withAuth;

