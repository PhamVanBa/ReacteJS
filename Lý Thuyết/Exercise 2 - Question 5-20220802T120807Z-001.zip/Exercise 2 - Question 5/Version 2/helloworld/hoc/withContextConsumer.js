import React from 'react';

function withContextConsumer(ContextComponent, WrappedComponent) {

    class HOC extends React.Component {

        render() {
            return (
                <ContextComponent.Consumer>
                    {context =>
                        <WrappedComponent {...this.props} contextProps={{
                            ...this.props.contextProps,
                            ...context
                        }} />
                    }
                </ContextComponent.Consumer>
            );
        }
    }

    HOC.displayName = `withContextConsumer(${getDisplayName(WrappedComponent)})`;

    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

export default withContextConsumer;

