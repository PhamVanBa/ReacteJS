import React from 'react';
import Login from '../components/Login';
import AuthenticatedContext from '../context/AuthenticatedContext';
import withContextConsumer from './withContextConsumer';

function withAuth(AuthenticatedComponent) {

    class HOC extends React.Component {

        isAuthenticated = () => {
            return this.props.contextProps.isAuthenticated;
        }

        render() {
            return !this.isAuthenticated() ? <Login /> : <AuthenticatedComponent {...this.props} />;
        }
    }

    HOC.displayName = `withAuth(${getDisplayName(AuthenticatedComponent)})`
    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

function AuthenticationWithContextConsumer(AuthenticatedComponent) {
    return withContextConsumer(AuthenticatedContext, withAuth(AuthenticatedComponent));
}


export default AuthenticationWithContextConsumer;

