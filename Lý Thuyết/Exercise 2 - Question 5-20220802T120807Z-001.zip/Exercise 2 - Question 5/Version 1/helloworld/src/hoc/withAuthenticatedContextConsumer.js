import React from 'react';
import AuthenticatedContext from '../context/AuthenticatedContext';

function withAuthenticatedContextConsumer(WrappedComponent) {

    class HOC extends React.Component {

        render() {
            return (
                <AuthenticatedContext.Consumer>
                    {context => <WrappedComponent {...this.props} authenticatedContext={context} />}
                </AuthenticatedContext.Consumer>
            );
        }
    }

    HOC.displayName = `withAuthenticatedContextConsumer(${getDisplayName(WrappedComponent)})`;

    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

export default withAuthenticatedContextConsumer;

