import React from 'react';
import AuthenticatedContext from '../context/AuthenticatedContext';

function withAuthenticatedContextProvider(WrappedComponent, context) {

    class HOC extends React.Component {

        render() {
            return (
                <AuthenticatedContext.Provider value={context}>
                    <WrappedComponent {...this.props} />
                </AuthenticatedContext.Provider>
            );
        }
    }

    HOC.displayName = `withAuthenticatedContextProvider(${getDisplayName(WrappedComponent)})`;

    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

export default withAuthenticatedContextProvider;

