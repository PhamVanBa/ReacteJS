import React from 'react';
import { ThemeContext } from '../context/ThemeContext';

function withThemeContextProvider(WrappedComponent, context) {

    class HOC extends React.Component {

        render() {
            return (
                <ThemeContext.Provider value={context}>
                    <WrappedComponent {...this.props} />
                </ThemeContext.Provider>
            );
        }
    }

    HOC.displayName = `withThemeContextProvider(${getDisplayName(WrappedComponent)})`;

    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

export default withThemeContextProvider;

