import React from 'react';
import { ThemeContext } from '../context/ThemeContext';

function withThemeContextConsumer(WrappedComponent) {

    class HOC extends React.Component {

        render() {
            return (
                <ThemeContext.Consumer>
                    {context => <WrappedComponent {...this.props} themeContext={context} />}
                </ThemeContext.Consumer>
            );
        }
    }

    HOC.displayName = `withThemeContextConsumer(${getDisplayName(WrappedComponent)})`;

    return HOC;
}

function getDisplayName(WrappedComponent) {
    return WrappedComponent.getDisplayName || WrappedComponent.name || 'Component';
}

export default withThemeContextConsumer;

