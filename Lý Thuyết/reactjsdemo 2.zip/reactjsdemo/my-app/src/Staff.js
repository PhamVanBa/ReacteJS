import React from "react";


// function Dong Vat 
// function Keu 

// ke thua lai function 
// function Meo
// function Cho

class Staff extends React.Component{
     constructor(props){
          super(props);

          this.state = {
              time: new Date()
          }
          
     }
  
     render(){
        return(
             <div>

                <div>fullName: {this.props.fullName}</div>
                <h2>Time: {this.state.time.toLocaleTimeString()}</h2>
                <button onClick={this.updateTime}>
                    Update Time
                </button>
             </div>
        )
     }
     updateTime = () => {
        this.setState(
            {
                time: new Date() 
            }
        )
     }

}
export default Staff