import './Person.css'
import React, { Component } from 'react'

Person.defaultProps = {
    class: 'Raiway'
}

function Person(props){
    return (
        <div> 
              <div>FullName: {props.fullName}</div>
              <div>Age: {props.age}</div>
              <div>Class: {props.class}</div>
              </div>
    )
}

export default Person
