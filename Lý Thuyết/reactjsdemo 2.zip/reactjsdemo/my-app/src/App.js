import logo from './logo.svg';
import './App.css';
import React, { Children } from "react"
import Person from './Person'
import Staff from './Staff';
import Bank from './component/Bank';
import Author from './component/Author';
import Table from './component/Table';
import Person1 from './component/Person1';

//import 'antd/dist/antd.css';
//import { Col, Row } from 'antd';
//import Layout from './component/Layout';

import User_State from './component/User_State'


const imgStyle = {
   withd: 300,
   height: 300,
}

const personNames = [
   {
      id: 1,
      firstName: "Nguyen Van",
      lastName: "A"
   },
   {
      id: 2,
      firstName: "Nguyen Van",
      lastName: "B"
   },
   {
      id: 3,
      firstName: "Nguyen Van",
      lastName: "C"
   }
]

const deletePersonById = (id) => {
   // get index 
   const personIndex = personNames.findIndex(p => { return p.id = id });
   const localPerson = [...personNames];
   localPerson.splice(personIndex, 1);

}

const personList = personNames.map(obj =>
   <Person1
      key={obj.id}
      firstName={obj.firstName}
      lastName={obj.lastName}
      click={deletePersonById(obj.id)}
   ></Person1>

)

const onClick = () => {
   console.log("Hello world");
}
// DATA JSON 
// data back end 
const characters = [
   {
      name: 'Ronaldo',
      job: 'Angular'
   },
   {
      name: 'Di Maria',
      job: 'Angular 1'
   },
   {
      name: 'Messi',
      job: 'ReactJS'
   },
   {
      name: 'A Young',
      job: 'Java'
   },
]

const name = "Trieu 123"

const characters1 = ['a', 'b', 'c', 'd', 'e']
//const listCharacters =  characters.map((element)=> <li>{element}</li>)

function App(props) {

   // non JSX return React.createElement("div", {style:divStyle},"Hello world");
   // JSX 
   //  return 
   //    <div id="parent">
   //     <div style={divStyle}>Hello World</div>
   //     <div></div>
   //   </div>

// const layout = () => {
//    <>
//    <Row>
//       <Col span={24}>Hello Component</Col>
//    </Row>
//    <Row>
//       <Col span={24}>Nav Component</Col>

//    </Row>
//    <Row>
//       <Col span={16}>
//          <div>Content left1</div>
//          <div>Content left2</div>
//       </Col>
//       <Col span={8}>Content right</Col>

//    </Row>
//    <Row>
//       <Col span={24}>Footer Component</Col>

//    </Row>
// </>

//}   
   return (

      <div className="parent">

         <Staff fullName="Trieu"/>

         {/* <User_State/> */}
         {/* <Author/> */}
            {/* <Bank fullName="Trieu" age="18" class="A01"><h1>ABBBBB</h1></Bank>  */}

         {/* <Layout/>   */}

         {/* <div>Hello</div>
                            
             {
                this.state.personNames.length > 0 &&
                personList
             }       */}


         {/* <ul>
                  {characters.map((element)=> <li key={index}>{element}</li>)}
             </ul> */}
         {/* {console.log(characters)} */}

         {/* <div>
                <Table characterData={characters} name={name}/>
            </div> */}

          {/* <Author/>
       
         <Staff fullName="Trieu 2"/>
          <Person fullName="Trieu" age="18" class="Rocket"/>
          <Person fullName="Nam" age="20"/> */}
          {/* <div onClick={onClick}>Button Click</div>
          <img style={imgStyle} src="https://imgresizer.eurosport.com/unsafe/1200x0/filters:format(png):focal(918x482:920x480)/origin-imgresizer.eurosport.com/2022/06/24/3398279-69445748-2560-1440.png"/>  */}
      </div>
   )
}

export default App;
