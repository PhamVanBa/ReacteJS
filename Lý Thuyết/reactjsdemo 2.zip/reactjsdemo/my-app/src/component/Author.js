import React, { Component } from 'react';


// New => ID => New Detail // getbyID
// component using props // New Detail component 
class Author extends Component {
    constructor(props){
        super(props)
        
        // state 
        // init
        this.state = {
            firstName : 'Kaito',
            lastName : 'Kit'
        }
    }
    handleChange = () => {
        console.log("on click");

        this.setState({
            firstName : 'Ronaldo'
        })
        this.setState({
            lastName : 'CR7'
        })
    }
    render() {
        return (
            <div>
                <p>Hello: {this.state.firstName} {this.state.lastName}</p>
                <br/>
                <button type="button" onClick={this.handleChange}>change name</button>
            </div>
        );
    }
}

export default Author;