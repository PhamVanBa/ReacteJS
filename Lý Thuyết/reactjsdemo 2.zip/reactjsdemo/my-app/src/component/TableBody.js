import App from "../App";
const TableBody = props => {


    console.log(props.characterData);
    // <App name1 = "nam1"/>

    // const rows = props.characterData.map((row,index) => {
    //     return (
    //         <tr key={index}>
    //             <td>{row.name}</td>
    //             <td>{row.job}</td>
    //         </tr>
    //     );
    // })
    
    // return <tbody>{rows}</tbody>
    
}

export default TableBody;
