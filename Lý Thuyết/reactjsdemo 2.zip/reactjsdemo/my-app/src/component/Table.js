import React, { Component } from 'react';
import TableHeader from './TableHeader'
import TableBody from './TableBody';

class Table extends Component {
    render() {
        // nhan du lieu app
        const {characterData} = this.props; 
        const {name} = this.props;
        return (
            
            <div>
                <div>Hello: {name}</div>
                <table>
                    <TableHeader/>
                    
                    <TableBody characterData={characterData}/>
                </table>
            </div>
        );
    }
}

export default Table;