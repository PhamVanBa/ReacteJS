import React, { Component } from 'react';
import './Person1.css'

class Person1 extends Person {

    renderFullName = () => {
        return `${this.props.firstName} ${this.props.lastName}`;
    }

    render() {
        return (
            <div className="person">
                 <h1>FullName: {this.renderFullName()}</h1>
                 <input type="text" placeholder="Input First Name" onChange={this.props.changeFirstName}/>
                <input type="text" placeholder="Input Last Name" onChange={this.props.changeLastName}/>
            </div>
        );
    }
}

export default Person1;