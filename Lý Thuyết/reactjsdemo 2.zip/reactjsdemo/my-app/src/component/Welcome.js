import React, { Component } from 'react';

class Welcome extends Component {
    
    render() {
       
        return (
            <div>
                Hello {this.props.fullName}
            </div>
        );
    }   
}
//const fullName = <Welcome fullName="Nguyen Van A"/>

Welcome.defaultProps = {
    fullName : "user"
}

export default Welcome;