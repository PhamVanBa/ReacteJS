import React, { Component } from 'react';

class Clock1{
    // call API 
    data 
    reject 
}
class Clock extends Component {

    data 
    render() {
        return (
            <div>
                <h2>{this.props.time.toLocaleTimeString()}</h2>
            </div>
        );
    }
}

export default Clock;