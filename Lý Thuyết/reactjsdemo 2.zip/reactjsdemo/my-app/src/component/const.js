
// API

// 
const personNames = [
    {
       id: 1,
       firstName: "Nguyen Van",
       lastName: "A"
    },
    {
       id: 2,
       firstName: "Nguyen Van",
       lastName: "B"
    },
    {
       id: 3,
       firstName: "Nguyen Van",
       lastName: "C"
    }
 ]