import React, { Component } from 'react';
import Clock from './Clock';

class Bank extends Component {

    data
    constructor(props) {
        super(props)
        this.state = {
            time : new Date()
        }
    }

    updateTime = () => {
        this.setState({
            time: new Date()
        })
    }

    render() {
        return (
            data 
            <div>
                {/* <h1>FullName: {this.props.fullName}</h1>
                <p>Age: {this.props.age}</p>
                <p>Year of Birth: {2020 - this.props.age}</p>
                <p>Class: {this.props.class}</p>
                <p>Slogan: {this.props.children}</p> */}

                
                <Clock time={this.state.time}/>
                
                <button onClick={this.updateTime}>
                    Update time
                </button>
            </div>
        );
    }
}

export default Bank;