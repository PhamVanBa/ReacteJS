import React from 'react';
import 'antd/dist/antd.css';
import { Col, Row } from 'antd';
imprt data

const Layout = () => (
  <>
    <Row>
      <Col span={24}>Hello Component</Col>
    </Row>
    <Row>
      <Col span={24}>Nav Component</Col>
      
    </Row>
    <Row>
      <Col span={16}>
              <div>Content left1</div>
              <div>Content left2</div>
      </Col>
      <Col span={8}>Content right</Col>
      
    </Row>
    <Row>
      <Col span={24}>Footer Component</Col>
    
    </Row>
  </>
);

export default Layout;