import React from 'react';
import ChildComponent from './ChildComponent';

function ParentComponent(props) {
    return (
        <ChildComponent />
    )
}

export default ParentComponent;


