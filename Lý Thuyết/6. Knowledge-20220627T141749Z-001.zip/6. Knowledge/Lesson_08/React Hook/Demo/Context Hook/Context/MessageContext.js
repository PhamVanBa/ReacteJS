import React from 'react';

const MesssageContext = React.createContext();

export default MesssageContext;


