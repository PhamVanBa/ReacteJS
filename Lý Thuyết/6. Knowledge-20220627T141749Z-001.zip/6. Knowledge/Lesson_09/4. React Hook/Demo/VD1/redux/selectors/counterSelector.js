const selectCounter = state => {
    return state.counter.value;
}

export default selectCounter;