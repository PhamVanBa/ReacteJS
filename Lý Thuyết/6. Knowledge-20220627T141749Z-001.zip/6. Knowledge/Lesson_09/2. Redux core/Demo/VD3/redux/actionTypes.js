export const ADD_TODO = "ADD_TODO";
export const INCREMENTED = "INCREMENTED";
export const DECREMENTED = "DECREMENTED";