import React from 'react';
import ChildComponent from './ChildComponent';

function ParentComponent(props) {
    return (
        <div>
            <ChildComponent />
        </div>
    )
}

export default ParentComponent;


