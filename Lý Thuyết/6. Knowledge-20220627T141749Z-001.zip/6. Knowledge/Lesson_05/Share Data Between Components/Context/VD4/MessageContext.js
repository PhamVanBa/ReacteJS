import React from 'react';

const MesssageContext = React.createContext();
MesssageContext.displayName = "MessageContext";

export default MesssageContext;


