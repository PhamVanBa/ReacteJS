import React from 'react';
import PersonList from './PersonList';

class App extends React.Component {

  render() {
    return (
      <div>
        <PersonList />
      </div>
    );
  }
}

export default App;

