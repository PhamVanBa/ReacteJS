import React from "react";

function Error() {
    return (
        <div>
            <h1> 404 - Error Page</h1>
        </div>
    );
};

export default Error;