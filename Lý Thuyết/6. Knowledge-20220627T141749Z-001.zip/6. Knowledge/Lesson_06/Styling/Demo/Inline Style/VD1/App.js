import './App.css';
import React from 'react';

class App extends React.Component {

  render() {

    return (
      <div>
        <h1 style={{ color: "Green", backgroundColor: "lightBlue", padding: "10px", fontFamily: "Arial" }}>FullName: Nguyen Van A</h1>
      </div >
    );
  }
}

export default App;


