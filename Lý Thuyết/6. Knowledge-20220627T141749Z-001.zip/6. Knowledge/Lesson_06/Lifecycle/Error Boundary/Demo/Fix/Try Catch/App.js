import React from 'react';
import Counter from "./Counter";

class App extends React.Component {

  render() {
    return (<Counter />);
  }
}

export default App;

