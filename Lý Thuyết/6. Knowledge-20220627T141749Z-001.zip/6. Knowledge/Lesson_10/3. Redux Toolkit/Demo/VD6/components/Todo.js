import React from "react";

function Todo(props) {
    return (
        <li>{props.todo}</li>
    );
};

export default Todo;
