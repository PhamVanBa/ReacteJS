import React from 'react';
import Counter from './components/Counter';

class App extends React.Component {

  render() {
    return (
      <div>
        <Counter />
      </div>
    );
  }
}

export default App;

