import React from "react"

import './App.css';
import UsingComponent from "./UsingComponent";

class App extends React.Component {

  render() {
    return (
      <div>
        <UsingComponent />
      </div>
    );
  }
}

export default App;