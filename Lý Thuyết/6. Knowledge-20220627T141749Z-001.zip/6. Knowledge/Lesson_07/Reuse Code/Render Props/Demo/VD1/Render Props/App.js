import './App.css'

import React from "react";
import MyComponent from './MyComponent';

class App extends React.Component {

  render() {

    return (
      <MyComponent />
    );
  }
}

export default App;



